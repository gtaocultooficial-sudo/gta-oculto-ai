import json, os, threading, uuid
from datetime import datetime
from pathlib import Path
from flask import Flask, jsonify, render_template, request

BASE = Path(__file__).resolve().parent
DATA = BASE / 'data'
DATA.mkdir(exist_ok=True)
STATE_FILE = DATA / 'state.json'
LOCK = threading.Lock()

app = Flask(__name__)

DEFAULT_TOPICS = [
    {"title":"GTA 6: o detalhe de Leonida que pode mudar a história", "score":94, "source":"Rockstar Games", "fresh":"ALTA", "status":"PRODUZIR"},
    {"title":"Jason e Lucia: o que a Rockstar já confirmou oficialmente", "score":92, "source":"Rockstar Games", "fresh":"ALTA", "status":"PRODUZIR"},
    {"title":"GTA 6 pode esconder pistas fora de Vice City", "score":88, "source":"Análise editorial", "fresh":"ALTA", "status":"ANALISAR"},
    {"title":"Um detalhe antigo de GTA V que voltou a chamar atenção", "score":74, "source":"Arquivo GTA", "fresh":"MÉDIA", "status":"RESERVAR"},
]


def load_state():
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding='utf-8'))
        except Exception:
            pass
    return {"engine":"OFFLINE", "topics":DEFAULT_TOPICS, "jobs":[], "produced":0}


def save_state(state):
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')


@app.get('/')
def index():
    return render_template('index.html')


@app.get('/health')
def health():
    return jsonify(ok=True, service='GTA Oculto AI Web', version='WEB-1.0')


@app.get('/api/state')
def state():
    with LOCK:
        s = load_state()
    return jsonify(s)


@app.post('/api/engine/heartbeat')
def heartbeat():
    payload = request.get_json(silent=True) or {}
    status = payload.get('status', 'ONLINE')
    with LOCK:
        s = load_state(); s['engine'] = status; s['engine_seen_at'] = datetime.utcnow().isoformat() + 'Z'; save_state(s)
    return jsonify(ok=True)


@app.post('/api/research')
def research():
    with LOCK:
        s = load_state(); s['topics'] = DEFAULT_TOPICS; save_state(s)
    return jsonify(ok=True, topics=DEFAULT_TOPICS)


@app.post('/api/jobs')
def create_job():
    payload = request.get_json(silent=True) or {}
    topic = (payload.get('topic') or '').strip()
    if not topic:
        topics = sorted(DEFAULT_TOPICS, key=lambda x: x['score'], reverse=True)
        topic = topics[0]['title']
    job = {
        'id': uuid.uuid4().hex[:10],
        'topic': topic,
        'status': 'AGUARDANDO PC',
        'created_at': datetime.utcnow().isoformat() + 'Z'
    }
    with LOCK:
        s = load_state(); s['jobs'].insert(0, job); save_state(s)
    return jsonify(ok=True, job=job)


@app.get('/api/jobs')
def jobs():
    return jsonify(load_state().get('jobs', []))


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '10000'))
    app.run(host='0.0.0.0', port=port, debug=False)
